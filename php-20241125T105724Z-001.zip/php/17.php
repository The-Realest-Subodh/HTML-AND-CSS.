<?php
session_start(); // Start the session

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['action'])) {
        $action = $_POST['action'];

        if ($action === 'Set/Update Program') {
            // Update the session variable with the form value
            $_SESSION['program'] = htmlspecialchars($_POST['program']);
            $message = "Session variable 'program' has been set/updated.";
        } elseif ($action === 'Delete Program') {
            // Delete the session variable
            unset($_SESSION['program']);
            $message = "Session variable 'program' has been deleted.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Session Variable</title>
</head>
<body>
    <h1>Manage Session Variable</h1>
    
    <!-- Form to set or update the session variable -->
    <form method="post" action="">
        <label for="program">Program:</label>
        <input type="text" id="program" name="program" value="<?php echo htmlspecialchars($_SESSION['program'] ?? ''); ?>" required><br><br>
        <input type="submit" name="action" value="Set/Update Program">
        <input type="submit" name="action" value="Delete Program">
    </form>

    <?php
    // Display message based on the action performed
    if (isset($message)) {
        echo "<p>$message</p>";
    }

    // Display the current value of the session variable if it is set
    if (isset($_SESSION['program'])) {
        echo "<h2>Current Session Variable Value:</h2>";
        echo "<p>Program: " . htmlspecialchars($_SESSION['program']) . "</p>";
    } else {
        echo "<p>No session variable 'program' is set.</p>";
    }
    ?>
</body>
</html>
