<h2>Form submitted successfully!</h2>
<p>Name: <?php echo $name; ?></p>
<p>Email: <?php echo $email; ?></p>
<p>Mobile: <?php echo $mobile; ?></p>
<p>Gender: <?php echo $gender; ?></p>
