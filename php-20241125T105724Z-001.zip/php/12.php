<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Page View Count</title>
</head>
<body>
    <h1>Welcome to the Page!</h1>

    <?php
    // Define the file path for the view count
    $file = 'view_count.txt';

    // Check if the file exists
    if (file_exists($file)) {
        // Read the current count from the file
        $count = (int)file_get_contents($file);
    } else {
        // Initialize count to 0 if the file doesn't exist
        $count = 0;
    }

    // Increment the count
    $count++;

    // Write the new count back to the file
    file_put_contents($file, $count);

    // Display the view count
    echo "<p>This page has been viewed " . $count . " times.</p>";
    ?>

</body>
</html>
