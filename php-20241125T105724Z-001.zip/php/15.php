<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Cookies</title>
</head>
<body>
    <h1>Manage Cookies</h1>
    <form method="post" action="">
        <label for="rollNumber">Roll Number:</label>
        <input type="text" id="rollNumber" name="rollNumber" value="<?php echo $_COOKIE['studentRollNumber'] ?? ''; ?>" required><br><br>

        <label for="name">Name:</label>
        <input type="text" id="name" name="name" value="<?php echo $_COOKIE['studentName'] ?? ''; ?>" required><br><br>

        <input type="submit" name="action" value="Set/Update Cookies">
        <input type="submit" name="action" value="Delete Cookies">
    </form>

    <?php
    // Handle form submission
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $action = $_POST['action'] ?? '';

        if ($action === 'Set/Update Cookies') {
            // Retrieve values from the form
            $rollNumber = htmlspecialchars($_POST['rollNumber']);
            $name = htmlspecialchars($_POST['name']);

            // Set cookies for 2 days (2*24*60*60 seconds)
            setcookie("studentRollNumber", $rollNumber, time() + (2 * 24 * 60 * 60));
            setcookie("studentName", $name, time() + (2 * 24 * 60 * 60));

            echo "<p>Cookies have been set/updated. Refresh the page to see the changes.</p>";
        } elseif ($action === 'Delete Cookies') {
            // Delete cookies by setting their expiration time to the past
            setcookie("studentRollNumber", "", time() - 3600);
            setcookie("studentName", "", time() - 3600);

            echo "<p>Cookies have been deleted.</p>";
        }
    }

    // Display cookies if set
    if (isset($_COOKIE['studentRollNumber']) && isset($_COOKIE['studentName'])) {
        $cookieRollNumber = htmlspecialchars($_COOKIE['studentRollNumber']);
        $cookieName = htmlspecialchars($_COOKIE['studentName']);

        echo "<h2>Current Cookie Values:</h2>";
        echo "<p>Roll Number: " . $cookieRollNumber . "</p>";
        echo "<p>Name: " . $cookieName . "</p>";
    } else {
        echo "<p>No cookies set.</p>";
    }
    ?>

</body>
</html>
