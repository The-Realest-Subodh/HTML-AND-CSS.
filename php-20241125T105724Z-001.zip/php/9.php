<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome Message</title>
</head>
<body>
    <h1>Welcome Message</h1>

    <?php
    // Check if the 'college' parameter is present in the URL
    if (isset($_GET['college'])) {
        // Retrieve and sanitize the 'college' parameter from the URL
        $college = htmlspecialchars($_GET['college']);
        
        // Display the welcome message
        echo "<h2>Welcome to " . $college . "</h2>";
    } else {
        // If 'college' parameter is not present, display a default message
        echo "<h2>Welcome! Please provide a college name in the URL.</h2>";
    }
    ?>

</body>
</html>
