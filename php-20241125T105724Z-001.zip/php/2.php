<?php
// Define the add function
function add($a, $b) {
    return $a + $b;
}

// Example usage of the add function
$result = add(5, 10);
echo "The sum of 5 and 10 is: " . $result;
?>
