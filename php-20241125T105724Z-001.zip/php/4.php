<?php
// Define the original 3x3 matrix
$matrix = [
    [1, 2, 3],
    [4, 5, 6],
    [7, 8, 9]
];

// Initialize the transpose matrix
$transpose = [];

// Calculate the transpose of the matrix
for ($i = 0; $i < 3; $i++) {
    for ($j = 0; $j < 3; $j++) {
        $transpose[$i][$j] = $matrix[$j][$i];
    }
}

// Display the original matrix
echo "Original Matrix:<br>";
for ($i = 0; $i < 3; $i++) {
    for ($j = 0; $j < 3; $j++) {
        echo $matrix[$i][$j] . " ";
    }
    echo "<br>";
}

// Display the transpose matrix
echo "Transpose Matrix:<br>";
for ($i = 0; $i < 3; $i++) {
    for ($j = 0; $j < 3; $j++) {
        echo $transpose[$i][$j] . " ";
    }
    echo "<br>";
}
?>
