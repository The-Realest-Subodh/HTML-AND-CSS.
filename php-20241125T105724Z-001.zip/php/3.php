<?php
// Define the fact function
function fact($n) {
    // Check if the number is between 1 and 100
    if ($n >= 1 && $n <= 100) {
        $factorial = 1;
        for ($i = 1; $i <= $n; $i++) {
            $factorial *= $i;
        }
        return $factorial;
    } else {
        return "Error: Number should be between 1 and 100.";
    }
}

// Example usage of the fact function
$number = 5; // You can change this value to test with different numbers
$result = fact($number);
echo "The factorial of $number is: " . $result;
?>
