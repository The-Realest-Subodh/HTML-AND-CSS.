<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Image Upload</title>
</head>
<body>
    <h1>Upload an Image</h1>
    <form method="post" enctype="multipart/form-data">
        <label for="image">Choose an image:</label>
        <input type="file" id="image" name="image" required><br><br>
        <input type="submit" value="Upload">
    </form>

    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Define the maximum file size (2MB)
        $maxFileSize = 2 * 1024 * 1024; // 2MB in bytes
        $uploadDir = 'uploads/'; // Directory to save uploaded images

        // Create the directory if it doesn't exist
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0777, true);
        }

        // Check if the file was uploaded without errors
        if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
            $fileTmpPath = $_FILES['image']['tmp_name'];
            $fileName = $_FILES['image']['name'];
            $fileSize = $_FILES['image']['size'];
            $fileType = $_FILES['image']['type'];
            $fileExtension = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));

            // Define allowed file extensions
            $allowedExtensions = ['jpg', 'jpeg', 'png', 'gif'];

            // Validate file size
            if ($fileSize > $maxFileSize) {
                echo "<p class='error'>File size exceeds the maximum allowed size of 2MB.</p>";
            }
            // Validate file extension
            elseif (!in_array($fileExtension, $allowedExtensions)) {
                echo "<p class='error'>Invalid file type. Only JPG, JPEG, PNG, and GIF files are allowed.</p>";
            }
            else {
                // Move the file to the upload directory
                $destination = $uploadDir . basename($fileName);
                if (move_uploaded_file($fileTmpPath, $destination)) {
                    echo "<p>File successfully uploaded: <a href='$destination'>$fileName</a></p>";
                } else {
                    echo "<p class='error'>There was an error uploading the file. Please try again.</p>";
                }
            }
        } else {
            echo "<p class='error'>No file uploaded or there was an upload error.</p>";
        }
    }
    ?>
</body>
</html>
