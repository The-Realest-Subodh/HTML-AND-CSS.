
<?php
session_start(); // Start the session

// Set the session variable if not already set
if (!isset($_SESSION['program'])) {
    $_SESSION['program'] = "Academic program";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Session Example</title>
</head>
<body>
    <h1>Session Variable Example</h1>
    <p>The value of the session variable <strong>'program'</strong> is: 
    <?php
    // Display the session variable
    echo htmlspecialchars($_SESSION['program']);
    ?>
    </p>
</body>
</html>
