<?php
// Define the associative multidimensional array
$sqlCommands = [
    [
        "SQL_cmd" => "CREATE",
        "Syntax" => "Create table table_name",
        "Example" => "Create table article;"
    ],
    [
        "SQL_cmd" => "DROP",
        "Syntax" => "Drop table table_name",
        "Example" => "Drop table article;"
    ],
    [
        "SQL_cmd" => "ALTER",
        "Syntax" => "Alter object_type object_name parameters;",
        "Example" => "Alter table article add subject varchar;"
    ]
];

// Display the contents of the array
echo "<h1>SQL Commands</h1>";
foreach ($sqlCommands as $command) {
    echo "<strong>SQL Command:</strong> " . $command['SQL_cmd'] . "<br>";
    echo "<strong>Syntax:</strong> " . $command['Syntax'] . "<br>";
    echo "<strong>Example:</strong> " . $command['Example'] . "<br><br>";
}
?>
