<?php
// Define the first 3x3 matrix
$matrix1 = [
    [1, 2, 3],
    [4, 5, 6],
    [7, 8, 9]
];

// Define the second 3x3 matrix
$matrix2 = [
    [9, 8, 7],
    [6, 5, 4],
    [3, 2, 1]
];

// Initialize the resultant matrix for storing the sum
$sumMatrix = [];

// Calculate the sum of the two matrices
for ($i = 0; $i < 3; $i++) {
    for ($j = 0; $j < 3; $j++) {
        $sumMatrix[$i][$j] = $matrix1[$i][$j] + $matrix2[$i][$j];
    }
}

// Display the first matrix
echo "First Matrix:<br>";
for ($i = 0; $i < 3; $i++) {
    for ($j = 0; $j < 3; $j++) {
        echo $matrix1[$i][$j] . " ";
    }
    echo "<br>";
}

// Display the second matrix
echo "Second Matrix:<br>";
for ($i = 0; $i < 3; $i++) {
    for ($j = 0; $j < 3; $j++) {
        echo $matrix2[$i][$j] . " ";
    }
    echo "<br>";
}

// Display the resultant sum matrix
echo "Sum Matrix:<br>";
for ($i = 0; $i < 3; $i++) {
    for ($j = 0; $j < 3; $j++) {
        echo $sumMatrix[$i][$j] . " ";
    }
    echo "<br>";
}
?>
