<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form Validation</title>
    <style>
        .error { color: red; }
    </style>
</head>
<body>
    <h1>Form Validation</h1>
    <form method="post" action="">
        <label for="name">Name:</label>
        <input type="text" id="name" name="name" required>
        <span class="error"><?php echo $nameError ?? ''; ?></span><br><br>

        <label for="email">Email:</label>
        <input type="email" id="email" name="email" required>
        <span class="error"><?php echo $emailError ?? ''; ?></span><br><br>

        <label for="mobile">Mobile (optional):</label>
        <input type="text" id="mobile" name="mobile">
        <span class="error"><?php echo $mobileError ?? ''; ?></span><br><br>

        <label>Gender:</label>
        <input type="radio" id="male" name="gender" value="Male" required>
        <label for="male">Male</label>
        <input type="radio" id="female" name="gender" value="Female" required>
        <label for="female">Female</label>
        <span class="error"><?php echo $genderError ?? ''; ?></span><br><br>

        <input type="submit" value="Submit">
    </form>

    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $name = htmlspecialchars($_POST['name']);
        $email = htmlspecialchars($_POST['email']);
        $mobile = htmlspecialchars($_POST['mobile']);
        $gender = htmlspecialchars($_POST['gender']);

        $nameError = $emailError = $mobileError = $genderError = "";
        $isValid = true;

        // Validate Name (alphabet only)
        if (!preg_match("/^[a-zA-Z\s]+$/", $name)) {
            $nameError = "Name is required and should contain only alphabets.";
            $isValid = false;
        }

        // Validate Email
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $emailError = "Please enter a valid email address.";
            $isValid = false;
        }

        // Validate Mobile (numeric)
        if (!empty($mobile) && !preg_match("/^[0-9]+$/", $mobile)) {
            $mobileError = "Mobile number should contain only numeric values.";
            $isValid = false;
        }

        // Validate Gender
        if (empty($gender)) {
            $genderError = "Gender is required.";
            $isValid = false;
        }

        // Include the output section if all validations pass
        if ($isValid) {
            include 'output_section.php';
        }
    }
    ?>
</body>
</html>
